/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;

/**
 *This package consists of enums that contains additional charges
 * @author DhanushaDommati
 */
public enum TransactionType {
     /**
     * Enumerated Constant the name Deposit
     */
    DEPOSIT,
    /**
     * Enumerated Constant the name Online purchase
     */
    ONLINEPURCHASE,
    /**
     * Enumerated Constant the name Withdraw
     */
    WITHDRAW;
}

    

